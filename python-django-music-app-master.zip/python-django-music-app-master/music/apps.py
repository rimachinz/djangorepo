from django.apps import AppConfig


class MymusicConfig(AppConfig):
    name = 'music'
