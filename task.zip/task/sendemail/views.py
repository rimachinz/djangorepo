from django.core.mail import send_mail
from django.conf import settings
from django.shortcuts import render



def index(request):
    send_mail('hai from noufi','how r u?','noufila.l@gmail.com',['chithrarajappan730@gmail.com'],fail_silently=False)
    return render(request,'index.html')
    # if request.method == 'POST':
    #     form = ContactForm(request.POST)
    #
    #     if form.is_valid():
    #         subject =form.cleaned_data['subject']
    #         message = form.cleaned_data['message']
    #         email_from = settings.EMAIL_HOST_USER
    #         recipient_list = ['noufila.l@gmail.com',]
    #         send_mail( subject, message, email_from, [recipient_list]),
    #
    #         return HttpResponse("Not send")