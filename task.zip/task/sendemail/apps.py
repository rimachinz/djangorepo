from django.apps import AppConfig


class SendemailConfig(AppConfig):
    name = 'sendemail'
