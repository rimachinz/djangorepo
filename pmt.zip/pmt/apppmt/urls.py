from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('manager/', views.ManagerCreate.as_view(), name='create_manager',),
    path('member/', views.MemberCreate.as_view(), name='create_member'),
    path('project/', views.ProjectCreate.as_view(), name='create_project'),
    path('issue', views.IssueCreate.as_view(), name='create_issue'),
    path('home/', views.home, name='home'),
    # path(r'document/add/$', views.DocumentCreate.as_view(), name='create_document'),
    #path(r'wiki/add/$', views.WikiCreate.as_view(), name='create_wiki'),


    # path('regman/', views.home, name='regman'),


]