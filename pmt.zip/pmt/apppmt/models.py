from django.db import models
from datetime import date,time
from django.urls import reverse
#from datetime.date.today()
from datetime import date




class manager(models.Model):
    first_name=models.CharField(max_length=30)
    last_name=models.CharField(max_length=30)
    age=models.CharField(max_length=30)
    email=models.EmailField(max_length=100)
    place = models.CharField(max_length=30)
    phone_no= models.CharField(max_length=30)
    qualification=models.CharField(max_length=30)
    username= models.CharField(max_length=30)
    password= models.CharField(max_length=100)
    category = models.CharField(max_length=30)

class member(models.Model):
    first_name=models.CharField(max_length=30)
    last_name=models.CharField(max_length=30)
    age=models.CharField(max_length=30)
    language=models.CharField(max_length=30)
    email=models.EmailField(max_length=100)
    place = models.CharField(max_length=30)
    phone_no= models.CharField(max_length=30)
    username= models.CharField(max_length=30)
    password= models.CharField(max_length=100)
    category = models.CharField(max_length=30)

class project(models.Model):
    topic=models.CharField(max_length=100)
    assignee=models.CharField(max_length=30)
    priority=models.CharField(max_length=30)
    description=models.TextField(max_length=500)
    start_date=models.DateField( default=date.today)
    end_date = models.DateField( default=date.today)

class issues(models.Model):
    topic=models.CharField(max_length=100)
    assignee=models.CharField(max_length=30)
    priority=models.CharField(max_length=30)
    start_date=models.DateField(default=date.today)
    end_date = models.DateField(default=date.today)

class document(models.Model):
    category=models.CharField(max_length=100)
    title=models.CharField(max_length=100)
    description=models.CharField(max_length=500)
    file=models.FileField(upload_to='documents/')

class wiki(models.Model):
    description=models.CharField(max_length=500)
    file=models.FileField(upload_to='documents/')

