from django.apps import AppConfig


class ApppmtConfig(AppConfig):
    name = 'apppmt'
