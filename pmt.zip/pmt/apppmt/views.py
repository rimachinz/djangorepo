from django.shortcuts import render
from django.http import HttpResponse

from .models import manager,member,project,issues,document,wiki
from django.views.generic.edit import CreateView,UpdateView,DeleteView
from django.urls import reverse_lazy





def index(request):
    #return HttpResponse("<h1>haiiii</h1>")
    return render(request,'base.html')

# def manager(request):
#     return render(request,'manager.html')
# def member(request):
#     return render(request,'member.html')
def home(request):
    return render(request,'home.html')
# def regman(request):
#     return render(request,'regman.html')
#
#

class MemberCreate(CreateView):
    model = member
    fields = ['first_name','last_name','age','language','email','place','phone_no','username','password','category']
    #success_url = reverse_lazy('apppmt:index')
class ManagerCreate(CreateView):
    model = manager
    fields = ['first_name','last_name','age','email','place','phone_no','qualification','username','password','category']

class ProjectCreate(CreateView):
    model = project
    fields = ['topic','assignee','priority','description','start_date','end_date']


class IssueCreate(CreateView):
    model = issues
    fields = ['topic', 'assignee', 'priority', 'start_date', 'end_date']
class DocumentCreate(CreateView):

    model = document
    fields = ['category', 'title', 'description', 'file']

class WikiCreate(CreateView):

    model = wiki
    fields = ['description', 'file']